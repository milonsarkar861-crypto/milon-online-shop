MILON ONLINE SHOP — MASTER SETUP (Bangladesh)

এই প্যাকেজটি আপনার existing Cloudflare Worker floral-surf-51e5-এর জন্য।
আগের static ZIP-এর বদলে এই package ব্যবহার করুন।

1) Cloudflare Dashboard > Workers & Pages > Workers KV > Create instance
   KV name: MILON_SHOP_STORE

2) Workers & Pages > floral-surf-51e5 > Settings > Bindings > Add > KV Namespace
   Variable name: STORE
   Namespace: MILON_SHOP_STORE
   তারপর Deploy.

3) Worker code/assets deploy করার সময় এই project-এর worker.js + public folder ব্যবহার করুন।
   wrangler.jsonc-তে STORE ID placeholder আছে; Dashboard binding ব্যবহার করলে binding name অবশ্যই STORE হতে হবে।

4) Shop URL: আপনার existing Worker URL-এর root
   Admin URL: আপনার existing Worker URL + /admin

5) Starter products inactive রাখা আছে। সঠিক brand, size, price, stock ও ছবি না দেওয়া পর্যন্ত Active করবেন না।

6) Default admin password: Milon@8613
   Public use-এর আগে password বদলানো জরুরি।

WHAT IS INCLUDED
- Customer storefront, search, cart, checkout, COD
- Product admin: add/edit/delete, photo upload, price/cost/stock, supplier, quality-test status
- Order admin: status, courier name, tracking number
- WhatsApp order message
- Facebook, WhatsApp and email contact buttons
- PWA/app-like install support
- Health check: /api/health

IMPORTANT LIMITS
- True Android push notification when the admin app/browser is fully closed needs Web Push keys/subscriptions; this package does NOT pretend that browser notification permission is the same thing.
- Automatic courier booking requires the chosen courier's merchant/API credentials and API contract.
- Automatic Facebook paid-ad creation requires Meta Business/Ad Account/API permissions and an approved access token.
- Online payment gateway requires merchant credentials.
These are external-account integrations, not something a ZIP can activate without your accounts/keys.

Do NOT put API secrets into public/index.html or public/admin.html.


FINAL KV CONFIG
Binding name: STORE
KV Namespace: MILON_SHOP_STORE
Namespace ID: 634c0fdad40e46b19113c42fa0a6df06

The Wrangler configuration in this package already contains the KV namespace ID above.
